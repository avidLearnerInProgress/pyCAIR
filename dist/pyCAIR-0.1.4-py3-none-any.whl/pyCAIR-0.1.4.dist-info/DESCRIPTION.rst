Content Aware Image Resizing

-Resize images using Seam Carving Algorithm

Explanation:
---------------

File: notdoneyet.py

1. Implemented Seam Carving Algorithm
   * getEnergy() - generated energy map using sobel operators and convolve function.
   * getMaps() - implemented the function to get seams using Dynamic Programming. Also, stored results of minimum seam in seperate list for backtracking.
   * drawSeam() - Plot seams(vertical and horizontal) using red color on image.
   * carve() - reshape and crop image.

2. Generated grayscale and energy maps using OpenCV.
   * generateEnergyMap()- utilised OpenCV inbuilt functions for obtaining energies and converting image to grayscale.
   * generateColorMap() - utilised OpenCV inbuilt functions to superimpose heatmaps on the given image.

3. Crop Columns
   * cropByColumn() - Implements cropping on both axes, i.e. vertical and horizontal.
   * cropByRow() - Rotate image to ignore repeated computations and provide the rotated image as an input to cropByColumn function.

4. Argparse library for user input
   * Parameters:
      * Alignment: Specify on which axis the resizing operation has to be performed.
      * Scale Ratio: Floating point operation between 0 and 1 to scale the output image.
      * Display Seam: If this option isn't selected, the image is only seamed in background. No output for seams is visible.
      * Input Image: Self Explanatory
      * Generate Sequences: Generate intermediate sequences to form a video after all the operations are performed.

5. Helpers
   * writeImage() - stores the images in results directory.
   * writeImageG() - stores intermediate generated sequence of images in sequences directory.
   * createFolder() - self explanatory
   * getFileExtension() - self explanatory

File: imgtovideos.py

1. Generate Video
   * _vid() - writes each input image to video buffer for creating a complete video
   * generateVideo() - pass each image path to _vid() for video generation

2. Helpers
   * getProcessPaths() - returns list of all sub-directories within a base path with certain conditions.
   * createFolder() - self explanatory 


